--Create a Server Audit

USE [master]

GO

CREATE SERVER AUDIT [activity_audit]
TO APPLICATION_LOG
WITH
(	QUEUE_DELAY = 1000
	,ON_FAILURE = CONTINUE
	,STATE=ON
)

GO

--Create Server Audit Specification

CREATE SERVER AUDIT SPECIFICATION [audit_logins]
FOR SERVER AUDIT [activity_audit]
ADD (SUCCESSFUL_LOGIN_GROUP)
WITH STATE=ON

GO

--Create Database Audit Specification

USE [AdventureWorks2012]

GO

CREATE DATABASE AUDIT SPECIFICATION [product_change_audit]
FOR SERVER AUDIT [activity_audit]
ADD (INSERT ON OBJECT::[Production].[Product] BY [public]),
ADD (UPDATE ON OBJECT::[Production].[Product] BY [public])
WITH STATE=ON

GO
